package com.mindtree.TestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mindtree.library.BrowseLaunch;
import com.mindtree.library.EmailAttachment;
import com.mindtree.library.Screenshot;
import com.mindtree.pages.LoginPage;
import com.mindtree.pages.ValidCredentials;

public class ValidCredentialsTestCase {
	static WebDriver driver;
	LoginPage lp;
	int i=0;
	@BeforeTest
	public void browserLaunch()
	{
		
		driver=BrowseLaunch.startBrowser("http://www.newtours.demoaut.com/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		lp=new LoginPage(driver);
		
	}
	@Test(priority=1)
	public void login()
	{
		lp.loginToSite("Savita20", "@Savita20");
		Screenshot.captureScreenShot(driver, "pass");
	}
	@Test(priority=2)
	 public static void FlightBook()
     {
             Select Passangers= new Select(driver.findElement(By.cssSelector("select[name='passCount']")));
             Passangers.selectByVisibleText("2");
             Select Departingfrom = new Select(driver.findElement(By.cssSelector("select[name='fromPort']")));
             Departingfrom.selectByVisibleText("Frankfurt");
             Select FromMonth = new Select(driver.findElement(By.cssSelector("select[name='fromMonth']")));
             FromMonth.selectByVisibleText("September");
             Select ArrivingIn = new Select(driver.findElement(By.cssSelector("select[name='toPort']")));
             ArrivingIn.selectByVisibleText("New York");
             Select ToMonth = new Select(driver.findElement(By.cssSelector("select[name='toMonth']")));
             ToMonth.selectByIndex(10);
             Screenshot.captureScreenShot(driver, "pass");
             driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[9]/td[2]/font/font/input")).click();
             driver.findElement(By.name("findFlights")).click();
             driver.findElement(By.name("reserveFlights")).click();
             driver.findElement(By.name("passFirst0")).sendKeys("Name1");
             driver.findElement(By.name("passLast0")).sendKeys("LastName");
             driver.findElement(By.name("creditnumber")).sendKeys("1234566");
             Screenshot.captureScreenShot(driver, "pass");
             driver.findElement(By.name("buyFlights")).click();
             
     }
	@Test(priority=3)
	public static void validCredentials()
	{
		String actual="AX 0";
		String expected=driver.findElement(By.xpath("(//font[@face='Arial, Helvetica, sans-serif, Verdana'])[9]")).getText();
		try
		{
		Assert.assertEquals(actual, expected);
		System.out.println("valid credentials");
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}
	}
	@Test(priority=4)
	public static void EmailAttach()
	{
		EmailAttachment.EmailAttach();
	}
	@Test(priority=5)
public static void Logout()
{
	driver.findElement(By.linkText("SIGN-OFF")).click(); 
}

	
	
@AfterTest
public void closeBrowser()
{
	driver.close(); 
}


}
