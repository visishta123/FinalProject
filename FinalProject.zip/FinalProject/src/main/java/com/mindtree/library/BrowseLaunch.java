package com.mindtree.library;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowseLaunch {
	static WebDriver driver;
	public static WebDriver startBrowser(String url)
	{
		String path="C:\\Users\\Personal\\Downloads\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
        driver.get(url);
		return driver;
		
	}

}
